﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lekcia
{
    /// <summary>
    /// Логика взаимодействия для Score.xaml
    /// </summary>
    public partial class Score : Window
    {
        public Score()
        {
            InitializeComponent();
            Cb_groupsc.SelectedValuePath = "id";
            Cb_groupsc.DisplayMemberPath = "Name";
            Cb_groupsc.ItemsSource = BDClass.bd.Group.ToList();


            Cb_Studentsc.SelectedValuePath = "Id";
            Cb_Studentsc.DisplayMemberPath = " NameFull";
            Cb_Studentsc.ItemsSource = BDClass.bd.Student.ToList();


            Cb_disceplinsc.SelectedValuePath = "id";
            Cb_disceplinsc.DisplayMemberPath = "Name";
            Cb_disceplinsc.ItemsSource = BDClass.bd.Disceplin.ToList();

        } 
        private void btn_dobavit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Zhurnal jurnal = new Zhurnal()
                {
                    IdStudent = (int)Cb_Studentsc.SelectedValue,
                    idDisceplin = (int)Cb_disceplinsc.SelectedValue,
                    Mark =Tb_Score.Text,

                };
                BDClass.bd.Zhurnal.Add(jurnal);
                BDClass.bd.SaveChanges();
                MessageBox.Show("Оценка студенту поставлена", "Поздравляю!", MessageBoxButton.OK);

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void Button_ends_Click(object sender, RoutedEventArgs e)
        {
            MainWindow newmainWindow = new MainWindow();
            newmainWindow.Show();//Для открытия нового окна создаем его объект и затем вызываем метод Show().//
            Hide();
        }

       
    }
}
