﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lekcia
{
    class BDClass
    {
        public static ShvidkojrEntities2 bd;
    }
}
