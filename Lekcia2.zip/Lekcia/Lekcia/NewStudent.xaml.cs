﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lekcia
{
    /// <summary>
    /// Логика взаимодействия для NewStudent.xaml
    /// </summary>
    public partial class NewStudent : Window
    {
        public NewStudent()
        {
            InitializeComponent();
            Cb_Special.SelectedValuePath = "id";
            Cb_Special.DisplayMemberPath = "Name";
            Cb_Special.ItemsSource = BDClass.bd.Cyrs.ToList();
            Cb_Form.SelectedValuePath = "id";
            Cb_Form.DisplayMemberPath = "Name";
            Cb_Form.ItemsSource = BDClass.bd.FormTeacher.ToList();
            Cb_namegroup.SelectedValuePath = "id";
            Cb_namegroup.DisplayMemberPath = "Name";
            Cb_namegroup.ItemsSource = BDClass.bd.Group.ToList();
        }

        private void ButtunEnd_Click(object sender, RoutedEventArgs e)
        {
            MainWindow newmainWindow = new MainWindow();
            newmainWindow.Show();//Для открытия нового окна создаем его объект и затем вызываем метод Show().//
            Hide();
        }

        private void btn_Create_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Student fIO = new Student()
                {
                    NameFull = Tb_fio.Text,
                    IdGroup = (int)Cb_namegroup.SelectedValue,
                    IdFormTraining = (int)Cb_Form.SelectedValue,
                    GodPastyplenia = Convert.ToInt32 (TB_God.Text),
                    IdCyrs = (int)Cb_Special.SelectedValue,
                };
                BDClass.bd.Student.Add(fIO);
                BDClass.bd.SaveChanges();
                MessageBox.Show("Студент добавлен", "Поздравляю!", MessageBoxButton.OK);

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
